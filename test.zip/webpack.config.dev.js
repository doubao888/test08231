var path = require('path');
var { join } = require('path');
var webpack = require('webpack');
var HtmlPlugin = require('html-webpack-plugin');
var autoprefixer = require('autoprefixer');

const DEBUG = process.env.NODE_ENV !== 'production';
// 开发环境
if (DEBUG && process.env.NODE_ENV !== undefined) {
  
}
module.exports = {
  mode: 'development',
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        use: {
          loader: 'babel-loader',
          options: {
            extends: join(__dirname, '.babelrc'),
            cacheDirectory: true,
          },
        },
        exclude: /node_modules/,
      },
      {
        test: /\.css$/,
        use: [
          {
            loader: 'css-loader',
            options: {
              minimize: true,
            },
          },
          {
            loader: 'postcss-loader',
            options: {
              plugins: () => [
                autoprefixer([
                  "last 3 versions",
                  "> 1%"
                ]),
              ],
            },
          },
        ],
        // include: 'node_modules',
      },
      {
        test: /\.less$/,
        use: [
          {
            loader: 'css-loader',
            options: {
              minimize: true,
            },
          },
          {
            loader: 'postcss-loader',
            options: {
              plugins: () => [
                autoprefixer([
                  "last 3 versions",
                  "> 1%"
                ]),
              ],
            },
          },
          {
            loader: 'less-loader',
            options: {
              javascriptEnabled: true,
            },
          },
        ],
        // include: 'node_modules',
      },
    ]
  },
  plugins: [
    new webpack.HashedModuleIdsPlugin(),
    new HtmlPlugin({
      // template: join(__dirname, 'src', 'index.ejs'),
      inject: true, // true: 'body', 'head'; false
      // filename: 'index.html',  // index.html
      title: 'test',
      description: 'test',
      keywords: 'test',
      minify: DEBUG ? {} : {
        collapseBooleanAttributes: true,
        collapseInlineTagWhitespace: true,
        collapseWhitespace: true,
        removeComments: true,
        removeEmptyAttributes: true,
        removeRedundantAttributes: true,
        removeStyleLinkTypeAttributes: true,
        removeScriptTypeAttributes: true,
        trimCustomFragments: true,
        minifyJS: true,
        minifyCSS: true,
        minifyURLs: true,
      },
    }),
  ]

};